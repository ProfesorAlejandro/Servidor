<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EJERCICIO3</title>
</head>
<body>
    <form action="validacion_login.php" method="POST">
        <input type="text" name="nombre" placeholder="Introduce el nombre">
        <br>
        <br>
        <input type="text" name="apellidos" placeholder="Introduce los apellidos">
        <br>
        <br>
        <button type="submit" name="btn_submit">LOG IN</button>
    </form>
</body>
</html>