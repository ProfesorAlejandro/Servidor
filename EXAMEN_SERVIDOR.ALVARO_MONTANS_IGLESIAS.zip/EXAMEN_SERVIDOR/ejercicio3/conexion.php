<?php
// Línea de conexión con la base de datos
$con = mysqli_connect('localhost','root','','transportistas_bd') or die("ERROR DE CONEXION");

