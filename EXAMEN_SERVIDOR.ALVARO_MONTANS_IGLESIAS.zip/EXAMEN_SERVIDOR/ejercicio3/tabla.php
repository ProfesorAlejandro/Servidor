<?php

echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
echo "<th>NOMBRE</th>";
echo "<th>APELLIDOS</th>";
echo "<th>ROL</th>";
echo "<th>OPERACIONES</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
