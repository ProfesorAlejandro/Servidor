<?php

require_once "conexion.php"; // Import del archivo 'conexion.php'
session_start(); // Inicio sesión
function eliminar($con){
    if(isset($_GET["id"])){
        $id = $_GET["id"];
        // Ejecución de la sentencia borrado sql
        $sql = "DELETE FROM transportistas where id = '$id'";
        $query = mysqli_query($con,$sql);

        // Si no se produce ningún error a la hora de ejecutar la consulta la página redireccionará
        // a 'admin.php' en un intervalo de 2 segundos
        if($query){
            echo "<h2>USUARIO ELIMINADO CORRECTAMENTE</h2>";
            header("refresh:1;url=admin.php");
        }
        else{
            echo "<h2>SE HA PRODUCIDO UN ERROR</h2>";
            header("refresh:1;url=admin.php");
        }  
    }
}

eliminar($con);