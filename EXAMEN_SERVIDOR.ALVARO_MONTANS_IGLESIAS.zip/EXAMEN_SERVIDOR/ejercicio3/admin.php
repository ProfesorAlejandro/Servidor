<?php
session_start();
// Verificación de acceso a la página
if($_SESSION["rol_usuario"] == "transportista"){
    echo "<h2>NO TIENES PERMITIDO EL ACCESO A ESTA SECCIÓN. Redireccionando...</h2>";
    header("refresh:2;url=rutas.php");
}
else{
    require_once "conexion.php";
    function listar($con){
        $sql = "SELECT * FROM transportistas INNER JOIN roles on transportistas.roles_id = roles.id WHERE roles.nombre_rol = 'transportista' ";
        $query = mysqli_query($con,$sql);
    
        require_once "tabla.php";
    
        while($usuarios = mysqli_fetch_assoc($query)){?>
            <tr>
                <td><?=$usuarios["nombre"]?></td>
                <td><?=$usuarios["apellidos"]?></td>
                <td><?=$usuarios["nombre_rol"]?></td>
                <td>
                    <button>
                        <a href="eliminar.php?id=<?=$usuarios["id"]?>">ELIMINAR</a>
                    </button>
                </td>
            </tr>
        <?php }
    
        echo "</tbody>";
        echo "</table>";
    }
    
    listar($con);
}
