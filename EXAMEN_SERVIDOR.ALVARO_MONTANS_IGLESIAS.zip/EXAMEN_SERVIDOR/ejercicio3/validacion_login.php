<?php
require_once "conexion.php";
session_start();
function iniciarSesion($con){

if(isset($_POST["btn_submit"])){
        $nombre = mysqli_real_escape_string($con,$_POST["nombre"]);
        $apellidos = mysqli_real_escape_string($con,$_POST["apellidos"]);
        $comprobacion = "SELECT * FROM transportistas INNER JOIN roles on transportistas.roles_id = roles.id WHERE nombre = '$nombre' AND apellidos = '$apellidos'";
        
        $query = mysqli_query($con,$comprobacion);
        if(mysqli_num_rows($query) > 0){
            $usuario = mysqli_fetch_assoc($query);
            // Creación de variable de sesión 
            $_SESSION["rol_usuario"] = $usuario["nombre_rol"];
            echo "<h2>SESIÓN INICIADA CORRECTAMENTE</h2>";
            if($_SESSION["rol_usuario"] == "admin"){
                header("refresh:2;url=admin.php");
            }
            else{
                header("refresh:2;url=rutas.php");
            }
        }
        else{
            echo "<h2>CREDENCIALES INCORRECTAS</h2>";
            header("refresh:2;url=index.php");
        } 
    }
}

iniciarSesion($con);