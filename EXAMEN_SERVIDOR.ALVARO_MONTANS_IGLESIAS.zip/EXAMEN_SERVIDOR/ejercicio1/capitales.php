<?php
// Comprobación de si esta declarada la variable 'btn_submit'
if(isset($_GET["btn_submit"])){
    $pais = $_GET["pais"];
    validacionCapitales($pais);
}
function validacionCapitales($pais){
    // Declaración variable global
    global $mensaje;
    if($pais == "fr"){
        $mensaje = "La capital de Francia es París";
    }
    if($pais == "esp"){
        $mensaje = "La capital de España es Madrid";
    }
    if($pais == "gre"){
        $mensaje = "La capital de Grecia es Atenas";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EJERCICIO1</title>
</head>
<body>
    <h2><?= $mensaje ?></h2>
</body>
</html>