<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EJERCICIO1</title>
</head>
<body>
    <!-- FORMULARIO DE PAISES DESPLEGABLE -->
    <form action="capitales.php">
        <select name="pais">
            <option value="">SELECCIONA UNA DE LAS OPCIONES</option>
            <option value="fr">Francia</option>
            <option value="esp">España</option>
            <option value="gre">Grecia</option>
        </select>
        <button type="submit" name="btn_submit">ENVIAR</button>
    </form>
</body>
</html>