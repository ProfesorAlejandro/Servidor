<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EJERCICIO2</title>
</head>
<body>
    <form action="validacion_registro.php" method="POST">
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="apellidos" placeholder="Apellidos">

        <h2>SELECCIONAR GÉNERO</h2>
        <label><input type="radio" name="genero" value="Masculino">Masculino</label>
        <label><input type="radio" name="genero" value="Femenino">Femenino</label>
        <br>
        <br>
        <button type="submit" name="btn_submit">REGISTRAR</button>
    </form>
</body>
</html>