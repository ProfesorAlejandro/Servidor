<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EJERCICIO2</title>
</head>
<body>
    <form action="" method="POST">
        <input type="checkbox" name="gen" value="Masculino">Masculino<br/>  
        <input type="checkbox" name="gen" value="Femenino">Femenino<br/> 
        <br>
        <button type="submit" name="button">FILTRAR</button> 
    </form>
    <br>
    <br>
</body>
</html>

<?php
require_once "conexion.php";
function listar($con){
    if(isset($_POST["button"])){
        // Se verifica si se ha seleccionado un género
        if(empty($_POST["gen"])){
            echo "Escoger género";
        }else{
            $genero = $_POST["gen"];
            $sql = "SELECT * FROM usuarios WHERE genero = '$genero'";
            $query = mysqli_query($con,$sql);
            // Llamada a archivo 'tabla.php' que contiene la estructura de la tabla de usuarios
            require_once "tabla.php";
            // Guardado de datos de base de datos en variable 'usuarios'
            while($usuarios = mysqli_fetch_assoc($query)){?>
                <tr>
                    <td><?=$usuarios["nombre"]?></td>
                    <td><?=$usuarios["apellidos"]?></td>
                    <td><?=$usuarios["genero"]?></td>
                </tr>
            <?php }

            echo "</tbody>";
            echo "</table>";
        }
    }
        
}
listar($con);


