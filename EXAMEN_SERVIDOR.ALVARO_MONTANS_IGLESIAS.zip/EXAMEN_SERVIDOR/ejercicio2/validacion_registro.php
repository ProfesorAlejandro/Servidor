<?php

require_once "conexion.php";

if(isset($_POST["btn_submit"])){
    $nombre = mysqli_real_escape_string($con,$_POST["nombre"]);
    $apellidos = mysqli_real_escape_string($con,$_POST["apellidos"]);
    $genero = mysqli_real_escape_string($con,$_POST["genero"]);
    // Comprobación de si el usuario ya está registrado
    $comprobacion = "SELECT * FROM usuarios WHERE nombre ='$nombre' AND apellidos = '$apellidos'";
    $q = mysqli_query($con,$comprobacion);
    
    if(mysqli_num_rows($q) == 0){
        $sql = "INSERT INTO usuarios VALUES(null,'$nombre','$apellidos','$genero')";
        $query = mysqli_query($con,$sql);
        if($query){
            echo "<h2>USUARIO REGISTRADO CORRECTAMENTE</h2>";
            header("refresh:3;url=listaUsuarios.php");
        }else{
            echo "<h2>ERROR DE CONEXIÓN/h2>";
        }
    }
    else{
        echo "<h2>EL USUARIO YA EXISTE</h2>";
    }
}