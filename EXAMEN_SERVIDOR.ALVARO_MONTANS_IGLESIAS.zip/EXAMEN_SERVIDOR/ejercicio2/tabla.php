<?php

echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
echo "<th>NOMBRE</th>";
echo "<th>APELLIDOS</th>";
echo "<th>GÉNERO</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";
