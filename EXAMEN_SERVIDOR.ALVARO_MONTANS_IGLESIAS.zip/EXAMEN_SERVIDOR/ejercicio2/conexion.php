<?php
// Línea de conexión con la base de datos
$con = mysqli_connect('localhost','root','','usuarios_database') or die("ERROR DE CONEXION");

