<?php

$capital_de_España=fopen("capital_de_España.txt","r2")
or die ("problemas al abrir capital_de_España.txt");

while (!feof($capital_de_España))
{
    $traer = fgets($capital_de_España);
   
}

$capital_de_Francia=fopen("capital_de_Francia.txt","r2")
or die ("problemas al abrir capital_de_Francia.txt");

while (!feof($capital_de_Francia))
{
    $traer = fgets($capital_de_Francia);
   
}



$capital_de_Grecia=fopen("capital_de_Grecia.txt","r2")
or die ("problemas al abrir capital_de_Grecia.txt");

while (!feof($capital_de_Grecia))
{
    $traer = fgets($capital_de_Grecia);
   
}

?>