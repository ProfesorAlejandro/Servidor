<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="index.php" method="$_GET">
    <input type="submit" value="ELIGE LA CAPITAL" name="elige_la_capital" />
    </form>

    <?php

if(isset($_GET['elige_la_capital'])){
    if(!is_dir('capital')){
        mkdir('capital' ,0777);
    }
}

if(is_dir('capital')){
    echo '<br>';
    echo "<button><a href='index.php?capital=capital_de_España'>España </button>";
    echo '<br><br>';
    echo "<button><a href='index.php?capital=capital_de_Francia'> Francia</button>";
    echo '<br><br>';
    echo "<button><a href='index.php?capital=capital_de_Grecia'>Grecia </button>";

   
}

function crearcapitalespaña(){

    if(isset($_GET['capital']) && ($_GET['capital'] == 'capital_de_España')){
        if(!file_exists('capital_de_España.txt')){
            $capitalespaña = fopen('./capital/capital_de_España.txt', "a+") or die("Error al 
            crear el archivo");

            fwrite($capitalespaña, "la capital de España es Madrid");
            fclose($capitalespaña);
           
        }
    }

}

function crearcapitalfrancia(){

    if(isset($_GET['capital']) && ($_GET['capital'] == 'capital_de_Francia')){
        if(!file_exists('capital_de_Francia')){
            $capitalfrancia = fopen('./capital/capital_de_Francia.txt', "a+") or die("Error al 
            crear el archivo");
            fwrite($capitalfrancia, "La capital de Francia es París");
            fclose($capitalfrancia);
        }
    }

}
function crearcapitalgrecia(){
    if(isset($_GET['capital']) && ($_GET['capital'] == 'capital_de_Grecia')){
        if(!file_exists('capital_de_Grecia')){
            $capitalgrecia = fopen('./capital/capital_de_Grecia.txt', "a+") or die("Error al 
            crear el archivo");
            fwrite($capitalgrecia, "la capital de Grecia es Atenas");
            fclose($capitalgrecia);
        }
    }

}


//Llamadas a funciones
crearcapitalespaña();
crearcapitalfrancia();
crearcapitalgrecia();



?>
</body>
</html>