<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="index.php"method="POST">
        <input type="text" name="username" placeholder="Nombre"/><br>
        <input type="text" name="apellidos" placeholder="Apellidos"/><br>
        <label>Selecciona tu genero</label> <br>
        <label>
         <input type='radio' value='1' name='masculino'>Masculino
        </label><br>
        <label>
         <input type='radio' value='2' name='femenino'>Femenino
        </label><br>

        <button type="submit" name="btn_registro">registrar</button>

    </form>

    <?php
    require_once 'conexion.php';
    session_start();

    function registrar($con){
        if(isset($_POST['btn_registro'])){
          
    
            if(!empty($_POST['username']) && !empty($_POST['apellidos']) && !empty($_POST['radio'])){
    
                $username = mysqli_real_escape_string($con, $_POST['username']); 
                $apellidos = mysqli_real_escape_string($con, $_POST['apellidos']);
                $masculino =  mysqli_real_escape_string($con, $_POST['masculino']);
                $femenino =  mysqli_real_escape_string($con, $_POST['femenino']);


                $sqlUnique = "SELECT * FROM usuarios WHERE username = '$username'";

                $queryUnique = mysqli_query($con,$sqlUnique);
                if($sqlUnique && mysqli_num_rows($con) > 0){

                 echo "EL USUARIO YA EXISTE";
    }
                $sqlinsert = "INSERT INTO usuarios VALUES(null,'$username','$apellidos','$masculino','$femenino')";
                $queryInsert = mysqli_query($con,$sqlinsert);
                
                if($queryInsert && mysqli_affected_rows($con) == 1){

                $_SESSION['usuario'] = $username;

                echo "<h2>USUARIO REGISTRADO</h2>";

                 header('refresh:2;url=home.php');

    }
            }
        }else{
            echo"<h2>los campos son obligatorios</h2>";
        } 
            mysqli_close($con);
    }

    //llamadas a funciones
    registrar($con);
            
   
    


    ?>

</body>
</html>