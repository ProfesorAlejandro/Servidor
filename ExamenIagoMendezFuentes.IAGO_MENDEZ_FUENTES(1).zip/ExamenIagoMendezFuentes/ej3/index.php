<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="index.php" method="POST">
        <input type="text" name="username" placeholder="Usuario" /><br>
        <input type="text" name="apellidos" placeholder="Apellidos"/><br>
        <input type="text" name="nombre_rol" placeholder="Nombre_rol"/><br>


        <button type="submit" name="btn_login">log in</button>
    </form>
    <?php
    $nombre_rol("admin" , "transportista");


    if $nombre_rol [0]



?>
</body>
</html>