<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PREGUNTA 1</title>
</head>

<body>
    <!-- un formulario con dos input, uno para cada nº. -->
    <form>
        <input type="number" name="numero1" placeholder="Numero 1"><br>
        <input type="number" name="numero2" placeholder="Numero 2"><br>

        <button type="submit" name="btn_submit">ENVIAR NUMEROS</button>
    </form>
    <?php

    // creamos la funcion que recibe como parametros las variables que almacenan 
    // los numeros introducidos por el usuario.
    function determinaMayor($numero1, $numero2)
    {
        // si tenemos los dos numeros y boton de enviar
        if (isset($_GET['btn_submit']) && isset($_GET['numero1']) && isset($_GET['numero2'])) {
            // almacenamos en dos variables esos GET

            $numero1 = $_GET['numero1'];
            $numero2 = $_GET['numero2'];
            // y sacamos por pantalla el mayor
            if ($numero1 >  $numero2) {
                echo "<h2>El numero mayor es $numero1</h2>";
            } else {
                echo "<h2>El numero mayor es $numero2</h2>";
            }
        }
    }



    // llamada a la funcion

    determinaMayor($numero1, $numero2);
    ?>
</body>

</html>