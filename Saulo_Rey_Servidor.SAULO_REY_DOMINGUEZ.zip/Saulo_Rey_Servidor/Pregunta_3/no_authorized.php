 <?php
    require_once 'conexion.php';
    function unAuthorized($con)
    {
        echo "<h1>USUARIO NO AUTORIZADO</h1>";
        header('refresh:2;url=index.php');
    }


    // llamada a la funcion
    unAuthorized($con);
