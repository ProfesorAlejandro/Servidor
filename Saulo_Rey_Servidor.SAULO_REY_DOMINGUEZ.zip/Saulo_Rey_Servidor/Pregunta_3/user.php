<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>PÁGINA DE USUARIOS</h2>

    <?php

    session_start();
// si es usuario, bienvenido usuario
    if (isset($_SESSION['user']) && $_SESSION['user'] == "user") {
        echo "Binevenido" . $_SESSION['user'];
    } else {
        header('location:index.php');
    }
    ?>

    <!-- tanto la pag user.php como gestor.php tendran un boton con el texto 
    "volver" que me permita ir al index.php -->
    <a href="index.php"><button type="button">VOLVER</button></a>
</body>
</html>