<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pregunta 3</title>
</head>

<body>
    <form action="index.php" method="POST">
        <input type="text" name="user" placeholder="USUARIO" /><br>
        <input type="text" name="rol" placeholder="ROL" /><br>

        <button type="submit" name="btn_submit">INICIAR SESIÓN</button>
    </form>

    <?php
    require_once 'conexion.php';
    session_start();

    function enviarDatos($con)
    {
        if (isset($_POST['btn_submit'])) {
            $username = $_POST['user'];
            $rol = $_POST['rol'];

            $sqlLogin = "SELECT * FROM usuarios WHERE username = '$username'";
            $queryLogin = mysqli_query($con, $sqlLogin);

            if ($queryLogin) {
                if (mysqli_num_rows($queryLogin) > 0) {
                    $user = mysqli_fetch_assoc($queryLogin);

                    $_SESSION['user'] = $user['username'];
                }
            } else {
                echo "<h2>ERROR DE LA BASE DE DATOS</h2>";
            }
        }
    }

    enviarDatos($con);

    ?>
</body>

</html>