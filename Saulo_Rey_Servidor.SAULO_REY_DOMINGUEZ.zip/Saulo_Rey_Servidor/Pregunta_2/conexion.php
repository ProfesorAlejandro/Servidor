<?php

$con = mysqli_connect('localhost','root','','ejercicio_dos')
       or die("<h2>ERROR DE CONEXIÓN</h2>") . mysqli_error($con);