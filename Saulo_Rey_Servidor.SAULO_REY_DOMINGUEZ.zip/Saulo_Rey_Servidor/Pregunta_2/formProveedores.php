<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>FORMULARIO DE PROVEEDORES</h1>

    <form action="registrar_proveedores.php" method="POST">

    <button type="submit" name="btn_1">tienda1</button><br><br>
    <button type="submit" name="btn_2">tienda2</button><br><br>
    <button type="submit" name="btn_3">tienda3</button><br><br>

    <input type="hidden" name="id" placeholder="ID" />
    <input type="text" name="nombre_proveedor" placeholder="Nombre" /><br>
    <input type="text" name="proveedor_id" placeholder="Proveedor_ID"/><br><br>

    <button type="submit" name="btn_registro_proveedores">ENVIAR DATOS</button>

    </form>
</body>
</html>