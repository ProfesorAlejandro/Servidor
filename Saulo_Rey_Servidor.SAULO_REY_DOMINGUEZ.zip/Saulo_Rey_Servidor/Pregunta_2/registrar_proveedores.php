<?php
require_once 'conexion.php';

function registrarProveedores($con){

    if(isset($_POST['btn_registro_proveedores'])){

        $id = $_POST['id'];
        $nombre_proveedor = $_POST['nombre_proveedor'];
        $proveedor_id = $_POST['proveedor_id'];

        $sqlInsertProveedor = "INSERT INTO proveedores VALUES(null,'$nombre_proveedor','$proveedor_id')";
        $queryInsertProveedor = mysqli_query($con, $sqlInsertProveedor);

        // affected porque es un insert
        if($queryInsertProveedor && mysqli_affected_rows($con) == 1){
            echo "<h2>PROVEEDOR REGISTRADO</h2>";
            // 2 es el tiempo en segundos
            header('refresh:2;url=registrar_proveedores.php');
        }else{
            echo "<h2>ERROR DE REGISTRO</h2>";
        }
    }

}

//LAMADAS A FUNCIONES
registrarProveedores($con);