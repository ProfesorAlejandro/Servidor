<?php

$con = mysqli_connect('localhost','root','','transportistas_bd')
    or die("<h2>Error de conexion</h2>") . mysqli_error($con);