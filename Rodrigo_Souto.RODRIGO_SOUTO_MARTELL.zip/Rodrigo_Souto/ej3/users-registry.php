<?php

require_once 'conexion.php';

function userRegistration($con){

    if(isset($_POST['btn_registry_users'])){
        $username = mysqli_real_escape_string($con, $_POST['nombre']);
        $password = mysqli_real_escape_string($con, $_POST['password']);

        $password_segura = password_hash($password, PASSWORD_BCRYPT,['const' => 4]);

        $sqlInsertUsers = "INSERT INTO usuarios VALUES(null, '$username', '$password_segura')";

        $queryInsertUsers = mysqli_query($con, $sqlInsertUsers);

        if($queryInsertUsers && mysqli_affected_rows($con) > 0){
            echo "<h2>USUARIO REGISTRADO</h2>";
        }
        else{
            echo "<h2>ERROR AL REGISTRAR EL USUARIO</h2>";
        }
    }

}

userRegistration($con);