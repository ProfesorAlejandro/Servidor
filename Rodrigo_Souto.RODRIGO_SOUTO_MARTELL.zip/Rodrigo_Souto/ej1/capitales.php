<?PHP

    function imprimirCapital(){
        if(isset ($_GET['paises']) && ($_GET['paises'] == 'francia')){
            echo 'LA CAPITAL DE FRANCIA ES PARIS';
        }
        else if (isset ($_GET['paises']) && ($_GET['paises'] == 'españa')){
            echo 'LA CAPITAL DE ESPAÑA ES MADRID';
        }
        else if (isset ($_GET['paises']) && ($_GET['paises'] == 'grecia')){
            echo 'LA CAPITAL DE GRECIA ES ATENAS';
        }
        else{
            echo 'NO HAY NINGUN PAIS SELECCIONADO';
        }

    }


    imprimirCapital();