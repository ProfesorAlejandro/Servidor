<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>

    <form action="lista.php" method="GET">
    <input type="checkbox" name="genero" value="masculino" />
    <label for="masculino">Masculino</label>
    <input type="checkbox" name="genero" value="femenino" />
    <label for="femenino">Femenino</label>
    
    <button type="submit" name="btn_buscar">BUSCAR</button>
    <br>
    <br>
    </form>

    <?php

        require_once 'conexion.php';
        require_once 'partials/tabla.php';

        function listar($con){

            $sqlListar = "SELECT * FROM usuarios";
            $select = mysqli_query($con, $sqlListar);

            while($usuarios = mysqli_fetch_assoc($select)){?>

                    <tr>
                        <td><?=$usuarios['nombre']?></td>
                        <td><?=$usuarios['apellidos']?></td>
                        <td><?=$usuarios['genero']?></td>
                    </tr>
            <?php }
        }

        function buscarGenero($con){
            if(isset ($_GET['btn_buscar']) && ($_GET['genero'] == 'masculino')){
                $sqlBuscar = "SELECT * FROM usuarios WHERE genero = 'masculino'";
                $selectBuscar = mysqli_query($con, $sqlBuscar);

                while($usuarios = mysqli_fetch_assoc($selectBuscar)){
                    echo $usuarios['nombre'] . ' ';
                    echo $usuarios['apellidos'] . ' ';
                    echo $usuarios['genero'] . '<br>'. '<br>';
                    
                }
            }
            elseif(isset ($_GET['btn_buscar']) && ($_GET['genero'] == 'femenino')){
                $sqlBuscar = "SELECT * FROM usuarios WHERE genero = 'femenino'";
                $selectBuscar = mysqli_query($con, $sqlBuscar);

                while($usuarios = mysqli_fetch_assoc($selectBuscar)){
                    echo $usuarios['nombre'] . ' ';
                    echo $usuarios['apellidos'] . ' ';
                    echo $usuarios['genero'] . '<br>'. '<br>';
                }
            }
            else{
                echo '<h1>ESCOGER GENERO</h1>';
            }
        }

        if(isset($_GET['btn_buscar'])){
            buscarGenero($con);
        }

        listar($con);


    ?>
    
</body>
</html>