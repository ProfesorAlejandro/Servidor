<?php

require_once 'conexion.php';

function registrar($con)
{

    if (isset($_POST['btn_registrar'])) {
        
        $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
        $apellidos = mysqli_real_escape_string($con, $_POST['apellidos']);
        $genero = $_POST['genero'];

        //Creación de la sentencia sql
        $sqlInsert = "INSERT INTO usuarios VALUES(null, '$nombre', '$apellidos', '$genero')";

        //Ejecutar la sentencia

        $insert = mysqli_query($con, $sqlInsert);

        if($insert) {
            header('Location:lista.php');
        }
        else{
            echo "<h2>Error al registrar el usuario</h2>";
        }
    }
}

registrar($con);
