<?php

echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
echo "<th>Nombre</th>";
echo "<th>Apellidos</th>";
echo "<th>Genero</th>";
echo "</tr>";
echo "<tbody>";