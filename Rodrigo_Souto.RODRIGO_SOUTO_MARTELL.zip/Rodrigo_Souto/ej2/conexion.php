<?php

$con = mysqli_connect('localhost','root','','usuarios_database');

if(!$con){
    echo "<h2>ERROR DE CONEXIÓN</h2>";
}