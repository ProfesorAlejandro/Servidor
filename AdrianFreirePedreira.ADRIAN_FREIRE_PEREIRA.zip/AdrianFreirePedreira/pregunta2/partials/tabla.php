<?php

echo "<table border='1px'>";
echo "<thead>";
echo "<tr>";
echo "<th>Tienda</th>";
echo "<th>Operaciones</th>";
echo "</tr>";
echo "<body>";