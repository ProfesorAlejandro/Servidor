<?php

$con = mysqli_connect('localhost', 'root', '', 'tienda_informatica') or die('Error de conexion') . mysqli_error($con);