<?php

require_once 'conexion.php';

function registrarEncargado($con){

    if(isset($_POST['btn_registro_encargado'])){

        $nombre = $_POST['nombre'];
        $apellidos = $_POST['apellidos'];
        $cargo = $_POST['cargo'];
        $tienda_id = $_POST['tienda'];

        $sqlInsertEncargado = "INSERT INTO encargados VALUES(null, '$nombre', '$apellidos', '$cargo', '$tienda_id')";
        $queryInsertEncargado = mysqli_query($con, $sqlInsertEncargado);

        if($queryInsertEncargado && mysqli_affected_rows($con) == 1){

            echo 'ENCARGADO REGISTRADO';
            header('refresh:2;url=index.php');
        }else{

            echo 'ERROR DE REGISTRO';
        }
    }
}

registrarEncargado($con);