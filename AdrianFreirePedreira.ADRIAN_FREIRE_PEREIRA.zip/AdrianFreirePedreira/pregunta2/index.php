<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="registrar_encargado.php" method="POST">
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="apellidos" placeholder="Apellidos">
        <input type="text" name="cargo" placeholder="Cargo">
        <select name="tienda">
            <option value="">SELECCIONAR TIENDA</option>
            <?php
                require_once 'conexion.php';

                $sqlSelectTienda = "SELECT id, nombre_tienda FROM tienda";
                $querySelectTienda = mysqli_query($con, $sqlSelectTienda);

                if($querySelectTienda && mysqli_num_rows($querySelectTienda) > 0){

                    while($tienda = mysqli_fetch_assoc($querySelectTienda)){ ?>

                        <option value="<?= $tienda['id'] ?>"><?= $tienda['nombre_tienda'] ?></option>
                <?php }
                }else{

                    echo 'ERROR DE BASE DE DATOS';
                }
            ?>
        </select>
        <br>
        <button type="submit" name="btn_registro_encargado">REGISTRAR ENCARGADO</button>
    </form>

</body>
</html>