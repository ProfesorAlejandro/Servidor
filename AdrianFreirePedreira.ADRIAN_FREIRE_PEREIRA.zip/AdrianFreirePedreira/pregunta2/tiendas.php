<?php

require_once 'conexion.php';

function verTiendas($con){

    $sqllistar = "SELECT * FROM tienda";
    $querySelect = mysqli_query($con, $sqllistar);

    include_once "partials/tabla.php";

    while($tiendas = mysqli_fetch_assoc($querySelect)){ ?>

        <tr>
            <td><?= $tiendas['nombre_tienda'] ?></td>
            <td>
                <button>
                    <a href="tiendas.php?id=<?=$tiendas['id']?>">ENCARGADO</a>
                </button>
            </td>
        </tr>

    <?php }
}

function verEncargado($con){

    if(isset($_GET['id'])){

        $tienda = $_GET['id'];

        $sql = "SELECT * FROM encargados WHERE id_tienda='$tienda'";
        $query = mysqli_query($con, $sql);

        if($query){

            while($encargado = mysqli_fetch_assoc($query)){

                echo 'Nombre: ' . $encargado['nombre_encargado'] . '<br>';
                echo 'Apellidos: ' . $encargado['apellidos_encargado'] . '<br>';
                echo 'Cargo: ' . $encargado['cargo'] . '<br>';
        
            }
        }
    }
}

verTiendas($con);
verEncargado($con);