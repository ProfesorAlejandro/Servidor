<?php

echo '<button><a href="home.php?cookie=borrar">ELIMINAR COOKIE</a></button><br>';

function verificar(){

    if(isset($_COOKIE['user'])){

        echo 'BIENVENIDO ' . $_COOKIE['user'] . '<br>';
    }else{

        header('Location:403.php');
    }

    if(isset($_GET['cookie'])){

        $borrarCookie = $_GET['cookie'];

        if($borrarCookie == 'borrar'){

            unset($_COOKIE['user']);
            setcookie('user','', time() -10);
            echo 'Cookie eliminada';
            header('refresh:2;url=form_usuario.php');
        }   
    }
}

verificar();