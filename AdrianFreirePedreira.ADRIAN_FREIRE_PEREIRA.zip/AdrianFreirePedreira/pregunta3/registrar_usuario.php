<?php

require_once 'conexion.php';

function registrarUsuario($con){

    if(isset($_POST['btn_registrar_usuario'])){

        $nombre = $_POST['nombre'];
        $password = $_POST['password'];
        $password_segura = password_hash($password, PASSWORD_BCRYPT, ['cost' => 4 ]);

        $sqlInsert = "INSERT INTO usuarios VALUES(null, '$nombre', '$password_segura')";
        $queryInsert = mysqli_query($con, $sqlInsert);

        if($queryInsert && mysqli_affected_rows($con) == 1){

            echo 'USUSARIO REGISTRADO';
            header('refresh:2;url=login.php');
        }else{

            echo 'ERROR DE REGISTRO';
        }
    }
}

registrarUsuario($con);