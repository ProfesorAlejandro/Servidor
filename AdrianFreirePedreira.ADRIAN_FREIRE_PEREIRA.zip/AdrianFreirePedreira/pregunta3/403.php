<?php

echo 'NO AUTORIZADO';

header('refresh:2;url=login.php');