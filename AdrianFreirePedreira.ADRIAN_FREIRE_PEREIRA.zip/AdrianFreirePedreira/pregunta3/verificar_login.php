<?php

require_once 'conexion.php';

function login($con){
    
    if(isset($_POST['btn_login'])){

        $username = mysqli_real_escape_string($con, $_POST['username']);
        $password = mysqli_real_escape_string($con, $_POST['password']);

        $sql = "SELECT * FROM usuarios WHERE nombre_usuario='$username'";
        $queryLogin = mysqli_query($con,$sql);

        if($queryLogin && mysqli_num_rows($queryLogin) > 0){

            $usuario = mysqli_fetch_assoc($queryLogin);

            $verify = password_verify($password, $usuario['password']);

            if($verify){
                setcookie('user', $username, time() + 86400);
                header('Location:home.php');
            }
            else{
                header('Location:403.php');
            }
        }
    }
}

login($con);