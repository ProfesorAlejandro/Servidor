<?php

$con = mysqli_connect('localhost', 'root', '', 'sistema_bd') or die('Error de conexion') . mysqli_error($con);