<?php

echo '<button><a href="form_usuario.php">REGISTRAR USUARIO</a></button>';
echo '<button><a href="login.php">LOGIN</a></button>';