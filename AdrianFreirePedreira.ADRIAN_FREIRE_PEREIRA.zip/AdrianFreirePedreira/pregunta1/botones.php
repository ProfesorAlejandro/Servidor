<?php

function procesarParametro(){

    if(isset($_GET['boton'])){

        $parametroBtn = $_GET['boton'];

        if($parametroBtn == 1){

            echo '<h1>Ha presionado el boton 1</h1>';
        }
        if($parametroBtn == 2){

            echo '<h1>Ha presionado el boton 2</h1>';
        }
        if($parametroBtn == 'error'){

            echo '<h1>'.$parametroBtn.'</h1>';
        }
    }
}

procesarParametro();