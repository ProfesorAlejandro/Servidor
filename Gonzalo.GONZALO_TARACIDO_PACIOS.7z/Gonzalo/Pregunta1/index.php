<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h3>CALCULA EL NÚMERO MAYOR</h3>

    <form action="index.php" method="POST">
        <input type="text" placeholder="Introduce un numero" name="numero1" />
        <input type="text" placeholder="Introduce otro numero" name="numero2" />
        <button type="submit" name="btn_calcular">CALCULAR</button>



</body>
</html>

<?php

//COMPROBAMOS QUE EL FORMULARIO SE HA ENVIADO

if(isset($_POST['btn_calcular'])){

    $numero1 = $_POST['numero1'];
    $numero2 = $_POST['numero2'];

    function numeroMayor($numero1,$numero2){

        if($numero1>$numero2){

            echo "El número mayor es el: " . $numero1;
        }
        if($numero2>$numero1){

            echo "El número mayor es el: " . $numero2;
        }if($numero1==$numero2){
            echo"Los números son iguales";
        }
    }
}

    //LLAMAMOS A LA FUNCIÓN

    numeroMayor($numero1,$numero2);


    