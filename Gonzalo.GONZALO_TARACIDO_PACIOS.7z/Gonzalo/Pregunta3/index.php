

    <?php

        session_start();

        require_once 'conexion.php';
      

        function login($con){

            $sqlDesplegable = "SELECT * FROM roles";
            $queryDesplegable = mysqli_query($con, $sqlDesplegable);
        
        
            echo "<form action='index.php' method='POST'>";
        
            echo "<input type='text' name='username'  placeholder='Usuario'/>";
            
            echo "<select name='roles'>";
            echo "<option value=''>SELECCIONA UN ROL</option>";
        
        
            if($queryDesplegable && mysqli_num_rows($queryDesplegable) > 0){
        
                while($roles = mysqli_fetch_assoc($queryDesplegable)){  ?>
        
                    <option value="<?=$roles['id'] ?>"><?= $roles['role_name'] ?></option>
        
             <?php   }
        
            }
            else{
                echo "<h2>ERROR AL CARGAR EL DESPLEGABLE</h2>";
            }
        
            echo "</select>";
            echo "<button type='submit' name='btn_form'>ENVIAR</button>";
            echo "</form>";
                

            if(isset($_POST['btn_form'])){
                $username = $_POST['username'];

                $rolName = $_POST['role_name'];
                

                $sql = "SELECT * FROM usuarios WHERE username='$username'";
                $query = mysqli_query($con,$sql);

                $_SESSION['usuario'] = $username;

               
                if($rolName== 'admin' && mysqli_num_rows($query) >0){
                    header('Location:admin.php');
                }

                if($rolName== 'user' && mysqli_num_rows($query) >0){
                    header('Location:user.php');
                }

                if($rolName== 'gestor' && mysqli_num_rows($query) >0){
                    header('Location:gestor.php');
                }


                else{
                    header('Location:no_authorized.php');
                }
            }
        }

        //Lamadas a funciones
        login($con);

    ?>
        
</body>
</html>

