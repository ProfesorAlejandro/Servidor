<?php

    require_once 'conexion.php';

    function registro($con){

        if(isset($_POST['btn_form'])){
       
                     
               $nombre = ($_POST['nombre']);
               $id_tiendasfk = ($_POST['tiendas']);               
       
               $sqlRegistroProveedor = "INSERT INTO proveedores VALUES(null,'$nombre', '$id_tiendasfk')";
               $queryRegistroProveedor = mysqli_query($con,$sqlRegistroProveedor );
       
               if($queryRegistroProveedor && mysqli_affected_rows($con) == 1){
                   echo "<h2>ALUMNO REGISTRADO</h2>";
                   
                   if($_POST['nombre_tienda'] = 'tienda1'){
          
                    header('Refresh:3; URL = tienda1.php');
         
                 }

                 if($_POST['nombre_tienda'] = 'tienda2'){
          
                    header('Refresh:3; URL = tienda2.php');
         
                 }

                 if($_POST['nombre_tienda'] = 'tienda3'){
          
                    header('Refresh:3; URL = tienda3.php');
         
                 }
       
               }
               else{
                   echo "<h2>ERROR DE REGISTRO</h2>";
               }
       
           }

           
       
       }
       
       
       
           // Llamadas a funciones
           registro($con);
   

       
    