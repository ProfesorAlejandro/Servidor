
<?php

require_once 'conexion.php';
function listarProveedores($con){

  

if(isset($_POST['btn_submit'])){

    $proveedor = $_POST['nombre_proveedor'];

    $id = $_POST['id'];

    $sqlListar = "SELECT * FROM proveedores WHERE id_tiendasfk='13'";
    $queryListar = mysqli_query($con,$sqlListar);

    echo "<table>";
    echo "<tbody>";

    if($queryListar && mysqli_num_rows($queryListar) >0){

        while($proveedor = mysqli_fetch_assoc($queryListar)){  ?>

            <tr>
                <td><?= $proveedor['nombre_proveedor']?></td>
               
            </tr>

        <?php }


    echo "</tbody>";
    echo "</table>";


    }
    else{
        echo "<h2>ERROR LISTANDO ALUMNOS</h2>";
    }


}


}

//Llamadas a funciones
listarProveedores($con);


?>


</body>
</html> 
